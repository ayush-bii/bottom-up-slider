const AppImages = {
    restro: require('../assets/images/image.jpeg'),
    search: require('../assets/images/search.png'),
    pin: require('../assets/images/pin.png'),
};

export default AppImages;