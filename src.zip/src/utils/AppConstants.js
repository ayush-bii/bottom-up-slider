const AppConstants = {
    screen_name: {
        Home: 'Home',
        Menu: 'Menu'
    }
};

export default AppConstants;