const AppColors = {
    white: '#fff',
    blue: '#453ae0',
};

export default AppColors;